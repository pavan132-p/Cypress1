import LoginPage from '../Pageobjects/LoginPage';
import AccountPage from '../Pageobjects/AccountPage';
import CartPage from '../Pageobjects/CartPage';

describe('Change Password Test', () => {
  const loginPage = new LoginPage();
  const accountPage = new AccountPage();
  const cartPage = new CartPage();

  beforeEach(() => {
    cy.visit('https://tutorialsninja.com/demo/'); // Use URL from config
  });

  it('Change password flow', () => {
    // Log in
    loginPage.login('testuser@example.com', 'password123');

    // Search for a product
    cy.get('input[name="search"]').type('MacBook');
    cy.get('button').contains('Search').click();

    // Add product to the cart
    cy.contains('MacBook').click();
    cy.get('button').contains('Add to Cart').click();

    // Proceed to checkout
    cartPage.proceedToCheckout();

    // Complete the order
    cy.get('input[name="agree"]').check();
    cy.get('button').contains('Confirm Order').click();

    // Change Password
    accountPage.navigateToMyAccount();
    accountPage.changePassword('newpassword123');

    // Assertion to validate password change
    cy.contains('Success: Your password has been updated.').should('be.visible');
  });
});