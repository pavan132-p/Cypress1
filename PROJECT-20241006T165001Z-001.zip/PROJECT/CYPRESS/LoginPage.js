class LoginPage {
    login(username, password) {
      cy.get('a[href$="login"]').click();
      cy.get('#input-email').type(username);
      cy.get('#input-password').type(password);
      cy.get('input[type="submit"]').click();
    }
  }
  export default LoginPage;